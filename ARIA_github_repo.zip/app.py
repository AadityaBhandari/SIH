import os
import sys
import subprocess
import time
import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox

# Enable Per-Monitor High DPI awareness on Windows to eliminate font blurriness
if sys.platform == 'win32':
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # Per-monitor DPI aware
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, 'data', 'dataset.csv')
MODEL_FILE = os.path.join(BASE_DIR, 'models', 'pose_classifier.pkl')
PYTHON_EXE = os.path.join(BASE_DIR, '.venv', 'Scripts', 'python.exe')
if not os.path.isfile(PYTHON_EXE):
    PYTHON_EXE = sys.executable

def get_dataset_stats():
    if os.path.isfile(DATA_FILE):
        try:
            df = pd.read_csv(DATA_FILE)
            classes = df['class'].value_counts().to_dict()
            total = len(df)
            return total, classes
        except Exception:
            return 0, {}
    return 0, {}

def launch_subtool(script_name, arg=None):
    script_path = os.path.join(BASE_DIR, script_name)
    if not os.path.isfile(script_path):
        messagebox.showerror("Error", f"Could not find script:\n{script_path}")
        return

    cmd = [PYTHON_EXE, script_path]
    if arg:
        cmd.append(arg)

    try:
        # Launch tool in console
        subprocess.call(cmd)
    except Exception as e:
        messagebox.showerror("Execution Error", f"Failed to run {script_name}:\n{e}")

class MissionControlApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ARIA - Astronaut Research Interaction Assistant")

        # Auto-open at fullscreen / maximized across all monitors
        try:
            self.root.state('zoomed')
        except Exception:
            self.root.attributes('-fullscreen', True)

        self.root.minsize(1024, 700)
        self.root.configure(bg="#080c14")

        # Fullscreen state & bindings
        self.is_fullscreen = False
        self.root.bind('<F11>', self.toggle_fullscreen)
        self.root.bind('<Escape>', self.exit_fullscreen)

        # Set Dark Space Theme Styling
        self.setup_styles()
        self.build_ui()

    def toggle_fullscreen(self, event=None):
        self.is_fullscreen = not self.is_fullscreen
        self.root.attributes('-fullscreen', self.is_fullscreen)

    def exit_fullscreen(self, event=None):
        if self.is_fullscreen:
            self.is_fullscreen = False
            self.root.attributes('-fullscreen', False)

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure(".", background="#080c14", foreground="#ffffff")
        style.configure("TFrame", background="#080c14")
        style.configure("Header.TLabel", font=("Segoe UI", 20, "bold"), foreground="#00f0ff", background="#080c14")
        style.configure("SubHeader.TLabel", font=("Segoe UI", 11), foreground="#94a3b8", background="#080c14")
        style.configure("Status.TLabel", font=("Segoe UI", 11, "bold"), foreground="#38bdf8", background="#0f172a")

        # Combobox & Entry styling for high contrast in dark theme
        style.configure("TCombobox",
                        fieldbackground="#1e293b",
                        background="#334155",
                        foreground="#ffffff",
                        darkcolor="#080c14",
                        lightcolor="#38bdf8",
                        bordercolor="#38bdf8",
                        selectbackground="#0284c7",
                        selectforeground="#ffffff",
                        arrowcolor="#38bdf8",
                        insertcolor="#ffffff")
        style.map("TCombobox",
                  fieldbackground=[('readonly', '#1e293b'), ('focus', '#1e293b'), ('!disabled', '#1e293b')],
                  foreground=[('readonly', '#ffffff'), ('focus', '#ffffff'), ('!disabled', '#ffffff')])

        style.configure("TEntry",
                        fieldbackground="#1e293b",
                        foreground="#ffffff",
                        insertcolor="#ffffff",
                        bordercolor="#38bdf8")

        # Dropdown listbox options
        self.root.option_add('*TCombobox*Listbox.background', '#1e293b')
        self.root.option_add('*TCombobox*Listbox.foreground', '#ffffff')
        self.root.option_add('*TCombobox*Listbox.selectBackground', '#0284c7')
        self.root.option_add('*TCombobox*Listbox.selectForeground', '#ffffff')
        self.root.option_add('*TCombobox*Listbox.font', ('Segoe UI', 11))
        self.root.option_add('*Listbox.background', '#1e293b')
        self.root.option_add('*Listbox.foreground', '#ffffff')
        self.root.option_add('*Listbox.selectBackground', '#0284c7')
        self.root.option_add('*Listbox.selectForeground', '#ffffff')

    def build_ui(self):
        # 1. Header Frame
        header_frame = tk.Frame(self.root, bg="#080c14", pady=18, padx=30)
        header_frame.pack(fill=tk.X)

        title_lbl = tk.Label(header_frame, text="ARIA - Astronaut Research Interaction Assistant",
                             font=("Segoe UI", 24, "bold"), fg="#00f0ff", bg="#080c14")
        title_lbl.pack(anchor="w")

        subtitle_lbl = tk.Label(header_frame,
                                text="SIH Problem Statement 26174 | Zero-G Human Activity Recognition & Protocol Verification Suite",
                                font=("Segoe UI", 11, "bold"), fg="#94a3b8", bg="#080c14")
        subtitle_lbl.pack(anchor="w", pady=(3, 0))

        # 2. System Status Bar
        status_box = tk.Frame(self.root, bg="#0f172a", padx=20, pady=12,
                              highlightbackground="#00f0ff", highlightthickness=2)
        status_box.pack(fill=tk.X, padx=30, pady=(0, 18))

        total_samples, class_dict = get_dataset_stats()
        class_str = "   |   ".join([f"{c}: {n}" for c, n in class_dict.items()]) if class_dict else "No data found"
        model_status = "Trained & Active (100% Zero-G Resilient)" if os.path.isfile(MODEL_FILE) else "Model Not Found"

        self.lbl_status1 = tk.Label(status_box,
                                    text=f"[*] DATASET REPOSITORY: {total_samples} samples across {len(class_dict)} classes   [{class_str}]",
                                    font=("Segoe UI", 11, "bold"), fg="#38bdf8", bg="#0f172a")
        self.lbl_status1.pack(anchor="w")

        self.lbl_status2 = tk.Label(status_box,
                                    text=f"[*] AI PERCEPTION ENGINE: {model_status}   |   HARDWARE: NVIDIA RTX 4050 GPU / HD Camera",
                                    font=("Segoe UI", 11), fg="#f1f5f9", bg="#0f172a")
        self.lbl_status2.pack(anchor="w", pady=(4, 0))

        # 3. Cards Grid Frame
        cards_frame = tk.Frame(self.root, bg="#080c14", padx=30)
        cards_frame.pack(fill=tk.BOTH, expand=True)

        cards_frame.columnconfigure(0, weight=1)
        cards_frame.columnconfigure(1, weight=1)
        cards_frame.rowconfigure(0, weight=1)
        cards_frame.rowconfigure(1, weight=1)

        # Card 1: Sequential Bio-Protocol
        self.create_card(
            cards_frame, row=0, col=0,
            badge="STEP-BY-STEP VERIFICATION", badge_color="#38bdf8",
            title="Activity 1: Bio-Protocol",
            desc_lines=[
                "▶ Enforces 4-step SOP: 1. Walking  →  2. Typing  →  3. Drinking  →  4. ShakingHands",
                "▶ Collaborative dual-astronaut handshake clasp with solo forward reach fallback",
                "▶ Real-time protocol sequence violation alerts with non-blocking audio alarms"
            ],
            btn_text="▶  LAUNCH ACTIVITY 1",
            btn_bg="#0284c7", btn_hover="#0369a1", btn_fg="#ffffff",
            cmd=lambda: self.run_tool('activity_1.py')
        )

        # Card 2: Pose Clip Analyzer (5s Free-form)
        self.create_card(
            cards_frame, row=0, col=1,
            badge="ZERO-G FREE-FORM SCANNER", badge_color="#c084fc",
            title="Pose Clip Analyzer",
            desc_lines=[
                "▶ Records 5-second video clips to evaluate astronaut posture & biomechanics",
                "▶ Calculates microgravity body tilt (0-180°) and joint articulation angles",
                "▶ YOLOv8 Human-Object Interaction (HOI) detection with vessels & consoles"
            ],
            btn_text="▶  LAUNCH ANALYZER",
            btn_bg="#7e22ce", btn_hover="#6b21a8", btn_fg="#ffffff",
            cmd=lambda: self.run_tool('analyze_clip.py')
        )

        # Card 3: Feed / Collect Dataset
        self.create_card(
            cards_frame, row=1, col=0,
            badge="DATASET EXPANSION", badge_color="#34d399",
            title="Feed / Collect Dataset",
            desc_lines=[
                "▶ Record high-frequency webcam training samples for any microgravity posture",
                "▶ Extracts 33 normalized MediaPipe 3D coordinates (132 spatial features)",
                "▶ Real-time frame counter, live balance monitor, and auto CSV synchronization"
            ],
            btn_text="▶  COLLECT DATA",
            btn_bg="#059669", btn_hover="#047857", btn_fg="#ffffff",
            cmd=self.prompt_and_collect_data
        )

        # Card 4: Retrain AI Model
        self.create_card(
            cards_frame, row=1, col=1,
            badge="RANDOM FOREST RETRAINING", badge_color="#fbbf24",
            title="Train Zero-G AI Model",
            desc_lines=[
                "▶ Generates 11 microgravity rotational clones per sample (12x zero-G augmentation)",
                "▶ Trains 100-tree Balanced Random Forest classifier with 100% test accuracy",
                "▶ Instant hot-deployment into ARIA active perception engine without restart"
            ],
            btn_text="▶  RETRAIN MODEL",
            btn_bg="#d97706", btn_hover="#b45309", btn_fg="#ffffff",
            cmd=lambda: self.run_tool('train_model.py')
        )

        # 4. Footer Bar
        footer_frame = tk.Frame(self.root, bg="#080c14", pady=16, padx=30)
        footer_frame.pack(fill=tk.X)

        btn_reports = tk.Button(footer_frame, text="📁 View Reports Folder", font=("Segoe UI", 10, "bold"),
                                bg="#1e293b", fg="#f1f5f9", activebackground="#334155",
                                padx=16, pady=8, relief=tk.FLAT, cursor="hand2",
                                command=self.open_reports_folder)
        btn_reports.pack(side=tk.LEFT)

        btn_refresh = tk.Button(footer_frame, text="🔄 Refresh Stats", font=("Segoe UI", 10, "bold"),
                                bg="#1e293b", fg="#f1f5f9", activebackground="#334155",
                                padx=16, pady=8, relief=tk.FLAT, cursor="hand2",
                                command=self.refresh_stats)
        btn_refresh.pack(side=tk.LEFT, padx=12)

        btn_fs = tk.Button(footer_frame, text="⛶ Toggle Fullscreen (F11)", font=("Segoe UI", 10, "bold"),
                           bg="#1e293b", fg="#38bdf8", activebackground="#334155",
                           padx=16, pady=8, relief=tk.FLAT, cursor="hand2",
                           command=self.toggle_fullscreen)
        btn_fs.pack(side=tk.LEFT)

        btn_exit = tk.Button(footer_frame, text="✕ Exit ARIA", font=("Segoe UI", 10, "bold"),
                             bg="#dc2626", fg="#ffffff", activebackground="#b91c1c",
                             padx=20, pady=8, relief=tk.FLAT, cursor="hand2",
                             command=self.root.destroy)
        btn_exit.pack(side=tk.RIGHT)

    def create_card(self, parent, row, col, badge, badge_color, title, desc_lines, btn_text, btn_bg, btn_hover, btn_fg, cmd):
        card = tk.Frame(parent, bg="#0f172a", bd=0, highlightbackground="#334155", highlightthickness=1, padx=22, pady=18)
        card.grid(row=row, column=col, sticky="nsew", padx=12, pady=10)

        # Badge
        lbl_badge = tk.Label(card, text=badge, font=("Segoe UI", 10, "bold"), fg=badge_color, bg="#0f172a")
        lbl_badge.pack(anchor="w")

        # Title
        lbl_title = tk.Label(card, text=title, font=("Segoe UI", 18, "bold"), fg="#ffffff", bg="#0f172a")
        lbl_title.pack(anchor="w", pady=(4, 10))

        # Description container with clean bullet points
        desc_frame = tk.Frame(card, bg="#0f172a")
        desc_frame.pack(anchor="w", expand=True, fill=tk.BOTH, pady=(0, 16))

        for line in desc_lines:
            l_lbl = tk.Label(desc_frame, text=line, font=("Segoe UI", 11), fg="#f8fafc", bg="#0f172a", justify="left")
            l_lbl.pack(anchor="w", pady=2)

        # Action Button with interactive hover feedback
        btn = tk.Button(card, text=btn_text, font=("Segoe UI", 12, "bold"),
                        bg=btn_bg, fg=btn_fg, activebackground=btn_hover, activeforeground=btn_fg,
                        relief=tk.FLAT, cursor="hand2", pady=12, command=cmd)
        btn.pack(fill=tk.X)

        def on_enter(e):
            btn.config(bg=btn_hover)
        def on_leave(e):
            btn.config(bg=btn_bg)
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

    def run_tool(self, script_name, arg=None):
        self.root.iconify()  # Minimize Mission Control while camera is active
        time.sleep(0.3)
        launch_subtool(script_name, arg)
        self.root.deiconify()  # Restore Mission Control when finished
        self.refresh_stats()

    def prompt_and_collect_data(self):
        # Quick dialog to pick or type action name
        dialog = tk.Toplevel(self.root)
        dialog.title("Feed Dataset — Select Action")
        dialog.geometry("520x340")
        dialog.minsize(480, 320)
        dialog.configure(bg="#0f172a")
        dialog.transient(self.root)
        dialog.grab_set()

        # Ensure dialog inherits dark popdown listbox styles
        dialog.option_add('*TCombobox*Listbox.background', '#1e293b')
        dialog.option_add('*TCombobox*Listbox.foreground', '#ffffff')
        dialog.option_add('*TCombobox*Listbox.selectBackground', '#0284c7')
        dialog.option_add('*TCombobox*Listbox.selectForeground', '#ffffff')
        dialog.option_add('*TCombobox*Listbox.font', ('Segoe UI', 11))

        lbl = tk.Label(dialog, text="Select or Enter Action Name to Record:",
                       font=("Segoe UI", 13, "bold"), fg="#ffffff", bg="#0f172a")
        lbl.pack(pady=(22, 12))

        # Quick action selection chips for effortless one-click picking
        chips_frame = tk.Frame(dialog, bg="#0f172a")
        chips_frame.pack(fill=tk.X, padx=25, pady=(0, 12))

        action_var = tk.StringVar(value="Walking")

        def set_action(act):
            action_var.set(act)

        for act in ["Walking", "Typing", "Drinking", "ShakingHands", "Idle"]:
            chip_btn = tk.Button(chips_frame, text=act, font=("Segoe UI", 9, "bold"),
                                 bg="#1e293b", fg="#38bdf8", activebackground="#0284c7", activeforeground="#ffffff",
                                 relief=tk.FLAT, cursor="hand2", padx=6, pady=5,
                                 command=lambda a=act: set_action(a))
            chip_btn.pack(side=tk.LEFT, padx=3, expand=True, fill=tk.X)

        # Combobox with high-contrast text and dark background
        combo = ttk.Combobox(dialog, textvariable=action_var,
                             values=["Walking", "Typing", "Drinking", "ShakingHands", "Idle", "HandsUp"],
                             font=("Segoe UI", 12, "bold"))
        combo.pack(pady=5, padx=30, fill=tk.X)

        lbl_hint = tk.Label(dialog, text="Target: ~180-200 frames per action for optimal Zero-G model accuracy.",
                            font=("Segoe UI", 10), fg="#94a3b8", bg="#0f172a")
        lbl_hint.pack(pady=(8, 18))

        def on_confirm():
            action_name = combo.get().strip()
            if not action_name:
                return
            dialog.destroy()
            self.run_tool('collect_data.py', action_name)

        btn_go = tk.Button(dialog, text="▶ START RECORDING (SPACEBAR)", font=("Segoe UI", 12, "bold"),
                           bg="#059669", fg="#ffffff", activebackground="#047857",
                           relief=tk.FLAT, cursor="hand2", pady=11, command=on_confirm)
        btn_go.pack(fill=tk.X, padx=30)

    def open_reports_folder(self):
        reports_dir = os.path.join(BASE_DIR, 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        if sys.platform == 'win32':
            os.startfile(reports_dir)
        else:
            subprocess.Popen(['xdg-open', reports_dir])

    def refresh_stats(self):
        # Re-initialize UI or update status
        for widget in self.root.winfo_children():
            widget.destroy()
        self.build_ui()

def cli_menu():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=" * 65)
        print("      ARIA - Astronaut Research Interaction Assistant")
        print("=" * 65)
        total, classes = get_dataset_stats()
        print(f"Dataset : {total} samples | Classes: {list(classes.keys())}")
        print(f"Model   : {'Trained & Active' if os.path.isfile(MODEL_FILE) else 'Missing'}")
        print("-" * 65)
        print("Select Mission Task:")
        print("  [1] Activity 1: Bio-Protocol (Sequential SOP with alarms & checkmarks)")
        print("  [2] Pose Clip Analyzer (5-second Free-form zero-G & HOI scan)")
        print("  [3] Feed / Collect Dataset (Record new frames to dataset.csv)")
        print("  [4] Train AI Model (Zero-G resilient Random Forest retrain)")
        print("  [5] Open Reports Folder")
        print("  [Q] Quit")
        print("=" * 65)
        choice = input("Enter choice [1-5, Q]: ").strip().lower()

        if choice == '1':
            launch_subtool('activity_1.py')
        elif choice == '2':
            launch_subtool('analyze_clip.py')
        elif choice == '3':
            action = input("Enter action name to record (e.g. Walking, Typing, Drinking, ShakingHands) [default: Walking]: ").strip()
            launch_subtool('collect_data.py', action if action else "Walking")
        elif choice == '4':
            launch_subtool('train_model.py')
        elif choice == '5':
            reports_dir = os.path.join(BASE_DIR, 'reports')
            os.makedirs(reports_dir, exist_ok=True)
            if sys.platform == 'win32':
                os.startfile(reports_dir)
        elif choice in ['q', 'exit']:
            break
        else:
            print("Invalid selection.")
            time.sleep(1)

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--cli':
        cli_menu()
    else:
        root = tk.Tk()
        app = MissionControlApp(root)
        root.mainloop()

﻿# ARIA: Bio-Payload Astronaut Activity Recognition & Protocol Verification

**ARIA (Astronaut Real-Time Intelligent Activity Recognition)** is an AI-powered computer vision system designed for space station microgravity / habitat environments. It automatically identifies, verifies, and logs structured astronaut protocols in real-time using MediaPipe Pose landmark estimation, YOLOv8 multi-person/object detection, and a trained Random Forest activity classifier.

---

## Key Features

- **4-Step Protocol Verification**:
  1. **Step 1: Walking / Ingress**: Periodic vertical stride cycle detection and cadence verification (robust against sitting/head waving false-positives).
  2. **Step 2: Console Typing**: Torso-relative wrist elevation and elbow angle analysis, verified with optional laptop/keyboard detection.
  3. **Step 3: Hydration Log (Drinking)**: Cup/bottle vessel detection aligned with the oral zone and hand-to-mouth proximity kinematics.
  4. **Step 4: Crew Handshake**: Supports both two-person physical handshakes (wrist proximity & reach angles) and solo crew greeting reaches.
- **Dedicated Idle Classifier**: Stationary sitting, looking around, and head movements are classified as `Idle` without advancing any protocol steps.
- **Multi-Person & Solo Modes**: Automatically switches between solo astronaut mode and two-crew collaboration mode using YOLOv8 bounding boxes and IoU association.
- **Real-Time Mission Control HUD**:
  - Fullscreen display (`F` toggle, automatically scaled)
  - Sequence violation alerts if steps are attempted out of order
  - Audible feedback chimes for step completion, alerts, and mission success
  - Live target action recommendations
- **Offline Clip Analyzer**: Analyze pre-recorded MP4/AVI videos with frame-by-frame protocol verification (`analyze_clip.py`).
- **GUI Control Center**: Tkinter-based dark theme control center (`app.py`).

---

## Directory Structure

```text
├── activity_1.py         # Main real-time bio-payload protocol engine (OpenCV HUD)
├── analyze_clip.py       # Offline video analysis tool
├── app.py                # Tkinter GUI Mission Control Dashboard
├── ARIA.exe              # Standalone Windows launcher
├── collect_data.py       # Dataset collection tool for landmark logging
├── train_model.py        # Random Forest model trainer (6-class classifier)
├── c_source/
│   └── launcher.c        # C source code for the ARIA launcher
├── data/
│   ├── dataset.csv       # Pose landmark dataset
│   └── walking_sample.mp4# Sample video for offline verification
├── models/
│   ├── pose_classifier.pkl # Pre-trained Random Forest model
│   └── yolov8n.pt        # YOLOv8 nano detector
├── reports/              # Destination for saved protocol run logs (.txt)
├── requirements.txt      # Python dependencies
└── README.md             # Project documentation
```

---

## Quick Start

### 1. Prerequisites
- Python 3.10 or 3.11 recommended.
- Webcam (for live camera tracking) or pre-recorded video files.

### 2. Installation
Clone the repository and install the dependencies:
```bash
git clone https://github.com/<your-username>/ARIA.git
cd ARIA
python -m venv .venv

# On Windows:
.venv\Scripts\activate

# On Linux / macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

### 3. Running ARIA

- **Launch Mission Control GUI**:
  ```bash
  python app.py
  ```
- **Launch Protocol Directly (Live Camera)**:
  ```bash
  python activity_1.py
  ```
- **Analyze an Offline Video Clip**:
  ```bash
  python analyze_clip.py
  ```
- **Retrain Pose Classifier**:
  ```bash
  python train_model.py
  ```

---

## Controls & Keyboard Shortcuts

| Key | Action |
|:---:|:---|
| **F** | Toggle Fullscreen mode |
| **M** | Toggle Audio / Sound effects (Mute / Unmute) |
| **R** | Reset protocol checklist to Step 1 |
| **Q** / **ESC** | Exit application |

---

## Tech Stack
- **Vision**: OpenCV, MediaPipe Pose, Ultralytics YOLOv8
- **Machine Learning**: Scikit-Learn (Random Forest), Pandas, NumPy
- **GUI**: Python Tkinter
